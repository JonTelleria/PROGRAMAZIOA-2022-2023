import java.util.Scanner;

public class Izenak {
    
    }

